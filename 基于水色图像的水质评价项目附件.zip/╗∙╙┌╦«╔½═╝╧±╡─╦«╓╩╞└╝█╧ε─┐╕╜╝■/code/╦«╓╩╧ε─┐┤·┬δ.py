from PIL import Image
import os
import numpy as np
from sklearn.model_selection import train_test_split
import re
import pandas as pd
import time

def var(rd):#构建三阶颜色矩的方法
    mid=np.mean((rd-rd.mean())**3)
    return np.sign(mid)*abs(mid)**(1/3)


def get_path():
    path = 'C:\\Users\\acer\\Desktop\\工作\\数据\\images\\'
    name = os.listdir(path)#取出文件夹下所有文件的文件名
    img_name=[]
    for i in name:
        if re.findall('\d_\d+\.jpg$',i)!=[]:
            img_name.append(i)
    return img_name      

def get_data_label():
    path = 'C:\\Users\\acer\\Desktop\\工作\\数据\\images\\'
    name=get_path()
    n=len(name)
    data=np.zeros([n,9])#初始化data，用来存储每张图片的RGB的123阶颜色矩
    labels=np.zeros([n])#存储标签
    
    for i in range(n):
        img=Image.open(path+name[i])
        M,N=img.size#像素矩阵的行列
        region=img.crop((M/2-50,N/2-50,M/2+50,N/2+50))#参数：起始行，起始列，结束行，结束列
        
        r,g,b=region.split()#分割像素通道
        
        rd=np.asarray(r)#转为array
        data[i,0]=rd.mean()#构建一阶颜色矩
        data[i,1]=rd.std()#构建二阶颜色矩
        data[i,2]=var(rd)#构建三阶颜色矩
        
        gd=np.asarray(g)#转为array
        data[i,3]=gd.mean()#构建一阶颜色矩
        data[i,4]=gd.std()#构建二阶颜色矩
        data[i,5]=var(gd)#构建三阶颜色矩
        
        bd=np.asarray(b)#转为array
        data[i,6]=bd.mean()#构建一阶颜色矩
        data[i,7]=bd.std()#构建二阶颜色矩
        data[i,8]=var(bd)#构建三阶颜色矩
        
        labels[i]=name[i][0]#文件的首个字符为标签
    return data,labels
            
data,labels=get_data_label()

pd.DataFrame(data).to_json('data')#预处理结果保存
pd.DataFrame(labels).to_json('data')#标签保存

#===================================以下开始模型训练及寻优============================
"""
网格搜索+决策树
"""
x_train,x_test,y_train,y_test=train_test_split(data,labels,test_size=0.2,random_state=1)
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import GridSearchCV
param_range = [i for i in range(1,100)]
param_range.append(None)
time_start=time.time()#模型训练计时开始
grid_search = GridSearchCV(estimator=DecisionTreeClassifier(),
                           param_grid=[
                               {"max_depth":param_range}
                           ],scoring="accuracy",cv=5)
    
grid_search = grid_search.fit(x_train,y_train)
time_end=time.time()#训练计时结束
print('模型训练时长为：',time_end-time_start)
grid_search.best_params_  #最好模型参数
grid_search.best_score_   #最好模型参数的准确率

clf = grid_search.best_estimator_    #选择最好的模型
pre=clf.predict(x_test)    #预测测试数据
pd.crosstab(y_test,pre,rownames=['label'],colnames=['predict'])#混淆矩阵
from sklearn.metrics import accuracy_score 
accuracy_score(y_test, pre)#准确率


"""
网格搜索+svm
"""
from sklearn.pipeline import Pipeline
from sklearn.svm import SVC
from sklearn.model_selection import GridSearchCV
from sklearn.preprocessing import StandardScaler
data1=data/255
x_train,x_test,y_train,y_test=train_test_split(data1,labels,test_size=0.2,random_state=1)
#初始化一个流水线类
pipe = Pipeline([("clf",SVC(random_state=1))])
#定义参数的取值
param_range = [0.0001,0.001,0.01,0.1,1.0,10.0,100.0,1000.0]
#定义一个网格搜索的参数

#线性的SVM只需要，只需要调优正则化参数C基于RBF核的SVM，需要调优gamma参数和C
param_grid = [{"clf__C":param_range,
               "clf__kernel":['linear']},
              {"clf__C":param_range,
               "clf__gamma":param_range,
               "clf__kernel":['rbf']}]
time_start=time.time()#计时开始
#网格搜索超参
grid_search = GridSearchCV(estimator=pipe,param_grid=param_grid,
                           scoring="accuracy",cv=10,n_jobs=-1)
grid_search = grid_search.fit(x_train,y_train)
time_end=time.time()#计时结束
print('模型训练时长为：',time_end-time_start)
#获取模型的最优超参
print(grid_search.best_params_)
#{'clf__C': 1000.0, 'clf__gamma': 10.0, 'clf__kernel': 'rbf'}
#获取最好的结果
print(grid_search.best_score_)

clf = grid_search.best_estimator_    #选择最好的模型
pre=clf.predict(x_test)   #预测测试数据
pd.crosstab(y_test,pre,rownames=['label'],colnames=['predict'])#混淆矩阵
from sklearn.metrics import accuracy_score 
accuracy_score(y_test, pre)#准确率


"""
网格搜索+神经网络
"""
from sklearn.neural_network import MLPClassifier
mlp = MLPClassifier(hidden_layer_sizes=(100,50), max_iter=500)

#定义参数的取值
param_range = [(100,50),(500,300),(100,50,20),]
max_iter_range=[100,500,1000]
param_grid = [{"hidden_layer_sizes":param_range,
               "max_iter":max_iter_range}]
#网格搜索超参
time_start=time.time()   #模型训练计时开始
grid_search = GridSearchCV(estimator=MLPClassifier(),param_grid=param_grid,
                           scoring="accuracy",cv=10,n_jobs=-1)
grid_search = grid_search.fit(x_train,y_train)
time_end=time.time()   #训练计时结束
print('模型训练时长为：',time_end-time_start)
#获取模型的最优超参
print(grid_search.best_params_)
# {'hidden_layer_sizes': (500, 300), 'max_iter': 1000}
#获取最好的结果
print(grid_search.best_score_)# 0.9506172839506173

clf = grid_search.best_estimator_    #选择最好的模型
pre=clf.predict(x_test)
pd.crosstab(y_test,pre,rownames=['label'],colnames=['predict'])#混淆矩阵
from sklearn.metrics import accuracy_score 
accuracy_score(y_test, pre)#准确率 1



